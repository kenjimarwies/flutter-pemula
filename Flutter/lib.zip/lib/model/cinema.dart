import 'dart:core';

class cinema {
  String picture;
  String title;
  String rate;
  String duration;
  List<String> genre;

  cinmea({this.picture, this.title, this.rate, this.duration, this.genre});
}
